# calculate Bxij and Byij
get.BxBy   <- function(x , y ,M){
  # check only lower triangular values, since M is symmetric
  M[upper.tri(M)] <- 0
  non.zero <- which(M!=0,arr.ind = T)
  # in case diagonal has a non zero entry, we exlude that
  non.diag <- non.zero[,1]!=non.zero[,2]
  # store indicies of lower triagular signs being not zero
  e.con    <- non.zero[non.diag,]
  # number of iterations needed 
  k        <- nrow(e.con)
  # number of covariates
  p        <- ncol(x)
  # initializing
  By       <- array(0, c(2,k))
  Bx       <- array(0, c(2,p-2,k))
  if (k!=0){ # if there are off diagonal elements (i.e. if we are not at the ridge case)
    # loop through all indicies
    for (d in 1:k){
      elem    <- e.con[d,]
      
      x.tilde <- cbind(x[,elem[1]],x[,elem[2]])
      x.exc   <- cbind(x[,-c(elem[1],elem[2])])
      
      Byij    <- fastols(y    , x.tilde)
      Bxij    <- fastols(x.exc, x.tilde)
      
      By[,d]  <- Byij
      Bx[,,d] <- Bxij
    }
  } else{  
    Bx <- 0
    By <- 0
  }
  return(list(Bx = Bx, By = By))
}

# update xi (actually used)
get.xi <- function(Bx ,By ,beta ,xi ,M){
  
  # check only lower triangular values, since M is symmetric
  M[upper.tri(M)] <- 0
  non.zero <- which(M!=0,arr.ind = T)
  # in case diagonal has a non zero entry, we exlude that
  non.diag <- non.zero[,1]!=non.zero[,2]
  # store indicies of lower triagular signs being not zero
  e.con    <- non.zero[non.diag,]
  # number of iterations needed 
  dd       <- nrow(e.con)
  if (dd!=0){
    for (i in 1:dd){
      beta.exc   <- beta[-c(e.con[i,1],e.con[i,2])]
      beta.tilde <- By[,i] - Bx[,,i]%*%beta.exc
      # updating only lower triangular part
      xi[e.con[i,1],e.con[i,2]] <- sign(beta.tilde[1])*sign(beta.tilde[2])
      
    }
    # updating upper triagular part
    xi[upper.tri(xi)] <- t(xi)[upper.tri(xi)]
    diag(xi) <- 1
  } else {
    xi <- M
  }
  return(xi)
}

# update M with a given initial M1 and estimated xi
update.M <- function(M1 ,xi){
  init       <- -(xi)*abs(M1)
  diag(init) <- abs(diag(M1)) # store diagonal values as in initial penalty matrix
  return(init)
}


# Function for soft-thresholding operator
soft.thresh <- function(x ,kappa){
  # initializing
  
  # changing according to rule
  if (abs(x)>kappa){
    x <- sign(x)*(abs(x)-kappa)
  } else{
    x <- 0
  }
  
  return(x)
}


###### coefficient updates ##########



beta.update.net <- function(x ,y ,beta=array(0,length(y)) ,lambda1 ,lambda2 ,M1 ,n.iter = 1e5 ,iscpp=TRUE ,tol=1e-6 ){
  
  beta <- as.matrix(beta)
  x    <- as.matrix(x)
  M1    <- as.matrix(M1)
  
  # initializing the variables
  i    <- length(beta)
  beta.previous           <- numeric(length(beta))
  k <- 1
  conv <- FALSE
  xy <- crossprod(x,y)
  xx <- crossprod(x)
  
  if (iscpp==TRUE){ # using cpp
    # access cpp function
    est   <- betanew_lasso_cpp(xx, xy, beta, M1, y, lambda1, lambda2, n.iter, tol)
    # store beta
    beta  <- est$beta
    # store steps until beta convergence
    k    <- est$steps
    # store value for convergence
    if(k < n.iter){
      conv <- TRUE
    }
    k <- k+1 # cpp starts at 0, thus the output gives one step less than R
  } else { # using R 
    
    while ((conv == FALSE) && (k-1 < n.iter) ) {
      # store previous beta
      beta.previous   <-  beta
      # update each at a time each coordinates
      for (j in 1:i){
        #  sum_i=1^n [ 2*{n*beta.tilde(j) + <xj,y> - sum_k=1^p [ <xj,xk> beta.tilde(k) ]} - 2*lambda2 sum_j!v [ M(jv) beta.tilde(v) ]
        numerator   <- 2*((length(y)*beta[j] + xy[j] - xx[,j]%*%beta)) - 2*lambda2*M1[j,-j]%*%beta[-j]
        #  2*n + 2*lambda2 M(jj)
        denominator <- 2*length(y)+2*lambda2*M1[j,j]
        # update beta(j) = numerator/denominator
        beta[j] <- soft.thresh(numerator,lambda1)/(denominator)
      }
      #update beta
      conv <- sum(abs(beta-beta.previous))<tol
      k <- k+1
    }
  }
  return(list(beta = beta, convergence = conv, steps = k-1))
}



#### grid search function ####

lasso.net.grid <- function(x ,y ,beta.0 = array(0,length(y)) ,lambda1=c(0,1) ,lambda2=c(0,1) ,M1 ,m.iter = 100, n.iter = 1e5 , iscpp=TRUE, tol=1e-6,  alt.num=12){
  # initializing beta
  beta <- beta.0
  
  # define penalty grid space
  n1 <- length(lambda1)
  n2 <- length(lambda2)
  # convert to relevant data structure
  beta    <- as.matrix(beta)
  x       <- as.matrix(x)
  M1      <- as.matrix(M1)
  
  # initialize values
  signs   <- FALSE
  xi      <- sign(t(x)%*%x)
  k       <- 0
  alt.id  <- 0
  
  
  # storage
  beta.store  <- array(0,c(length(beta), n2, n1))   
  M.store     <- array(0,c(length(beta), length(beta), n2, n1))   
  k.store     <- array(0,c(n2,n1))
  n.store     <- array(0,c(n2,n1))
  conv.store  <- array(0,c(n2,n1)) 
  conv.store2 <- array(0,c(n2,n1))
  alt.store   <- array(0,c(dim(M),alt.num))
  alt.beta    <- array(0,c(length(beta),alt.num))
  alt.xi.store<- array(0,c(dim(xi),alt.num))
  mse         <- array(0,c(n2,n1))
  
  alt.save    <- NULL
  xi.conv     <- NULL
  xi.conv1    <- NULL
  xi.conv2    <- NULL
  
  
  # storage for warm starts
  beta.l1w <- numeric(length(beta)) # warm start for lambda1 
  beta.l2w <- numeric(length(beta)) # warm start for lambda2
  
  # store matrices Bx and By for xi update before loops 
  BxBy <- get.BxBy(x,y,M1)
  Bx   <- BxBy$Bx
  By   <- BxBy$By
  
  
  
  for (i in 1:n2) {
    # loop through lambda2
    
    cat("Looping through lambda2 - ", i, "\n") 
    for (j in 1:n1) {
      
      # loop through lambda1
      cat("Looping through lambda1 - ", j, "\n") 
      # store check value for beta convergence given updated M 
      betaconv <- FALSE
      # while loop for xi convegence
      while ((signs != TRUE)  && (k < m.iter) && (betaconv != TRUE)) {
        # upate the penalty matrix before the estimation
        M   <- update.M(M1,xi)
        # estimates lasso with network given lambda1, lambda2 and M matrix
        est <- beta.update.net(x,y,beta,lambda1[j],lambda2[i],M,n.iter,iscpp)
        # if coordinate descent does not converge, repeat until convergence in absolute difference:
        if(est$convergence == FALSE) {
          betaconv <- FALSE
          beta <- beta.l2w # using coordinate descent warm start
          n.iter <- n.iter*10
          cat("Coordinate descent alogrithm starts again. GRID VALUES *** lambda1 - ", j, "lambda2 - ", i, " n.iter is set to - " , n.iter , "\n")
          cat("Current beta estimate - " , est$beta , "\n")    
          cat("Current beta warm start - " , beta , "\n")  
          }
        else{
          # update xi with "covariance" type updates. sec 2.2.
          xi.u <- get.xi(Bx,By,est$beta,xi,M1)
          
          # store coordinate descent convergence output
          if(est$convergence == TRUE) {
            betaconv <- TRUE
          } 
          
          # check for alternating signs if iterator is close to maximum number of iteration
          if(k >= m.iter-alt.num){
            id <- m.iter-k-alt.num+1
            alt.xi.store[,,id] <- xi
            alt.beta[,id]     <- est$beta
          } 
          if(k == m.iter) 
          {
            alt.id                   <- alt.id + 1 
            alt.save$beta[[alt.id]]  <- alt.beta
            alt.save$xi[[alt.id]]    <- alt.xi.store
            alt.save$lams[[alt.id]]  <- c(lambda1[j],lambda2[i])
          }
          
          # update iterations number
          k <- k + 1
          # check xi matrix with all previous matrices
          xi.conv[[k]] <- cbind(which(xi.u!=xi, arr.ind = T),as.matrix(xi.u[which(xi.u!=xi, arr.ind = T)]))
          # check for convergence or stop once interations reaches n.iter
          signs <- isTRUE(all.equal(xi.u,xi))
          
          # update xi
          xi <- xi.u
          # storing warm starts for beta lambda1 (the first converged beta)
          if (k == 1 && j == 1){
            beta.l1w <- est$beta
          }
          # updating beta for M warm start
          beta <- est$beta
        }
      } # Iterations through sign Matrix finishes here. [either converged or signs alternate]
      # store xi check
      
      xi.conv1[[j]] <- xi.conv
      # store number of iterations
      k.store[i,j]     <- k 
      n.store[i,j]     <- est$steps
      conv.store[i,j]  <- signs
      if(betaconv == FALSE) { # store last boolean value of convergence for betas
        conv.store2[i,j] <- FALSE # at least one of the iterations in M did not have convergence for betas
      }
      else {
        conv.store2[i,j] <- betaconv 
      }
      # reinitialize k and signs variables
      k     <- 0
      signs <- FALSE
      # storing warm starts for beta lambda1 at last point in grid (n1) (the first converged beta)
      # beta.l1w because we store a warm start with no M loop (i.e. the first beta that has converged)
      beta.l2w <- beta.l1w
      # storing converged values with lambda1 and lambda2 given.
      beta.store[,i,j]  <- beta
      # compute MSE 
      mse[i,j]  <- mean((y - x%*%beta)^2)
      # store M1 values that
      M.store[,,i,j]    <- sign(xi)*abs(M1)
      # update beta for lambda1 warm start
      beta <- beta.l1w
      
    } # end of for loop n1  (through lambda1)
    
    # store xi check
    xi.conv2[[i]] <- xi.conv1
    # update beta for lambda2 warm start
    beta <- beta.l2w
  }   # end of for loop n2  (through lambda2)
  
  return(list(beta = beta.store, mse = mse, signMat = M.store, iterations = k.store, update.steps = n.store, convergence.in.M = conv.store, convergence.in.grid = conv.store2, xi.conv = xi.conv2, alt.info = alt.save))
}


### ADDITIONAL FUNCTIONS ######


# draw data

drawdata <- function(n,beta){
  p <- length(beta)
  x <- matrix(rnorm(n*p),n,p)
  y <- x%*%beta + rnorm(n, mean = 0, sd = sqrt(sum(beta^2)/4))
  return(list(y=y,x=x))
}


# fast ols (file fast_ols shows with simulated data that this is the fastest way in R)
fastols <- function (y ,x) { 
  XtX <- crossprod(x) 
  Xty <- crossprod(x, y) 
  return(solve(XtX, Xty)) 
}



##############################
# ADDITIONS                  #
##############################


#---ADD-ON FUNCTIONS FOR SIMULATION ANALYSIS---#

mat.to.laplacian <- function(M1, type = "normalized"){
  
  degree.vec <- apply(M1,2,sum)
  
  if(type=="normalized"){
    du.dv.mat <- sqrt(as.matrix(degree.vec) %*% t(as.matrix(degree.vec)))
    du.dv.mat[which(du.dv.mat == 0)] <- 1
    L <- -1 * M1 / du.dv.mat
    L <- L + diag(sign(degree.vec))
  } 
  if(type=="combinatorial"){
    L <- - M1 + diag(degree.vec)
  }
  return(L)
}



CVfold <- function(n,K=10, is.random = FALSE){
  
  # determine if draw random indices or sequential
  if(is.random){
    id    <- sample(n,replace = FALSE)
  } else {
    id <- seq(n)  
  }
  
  # get indices:
  k <- as.integer(n*seq(1,K-1)/K)
  k <- matrix(c(0,rep(k,each=2),n),ncol=2,byrow=TRUE)
  k[,1] <- k[,1]+1
  ind <- lapply(seq.int(K),function(x,k,d) list(train=d[!(seq(d) %in% seq(k[x,1],k[x,2]))],validate=d[seq(k[x,1],k[x,2])]),k=k,d=id)
  return(ind)
}

#--data simulations---#
simul.data      <- function(p.1, p.2, n, beta.1, beta.2, beta.3, beta.4, t) {
  ###
  #  This function simulates the data according to Weber et. al (2014) pape
  # 
  ###
  
  # number of covariates: 
  p <- p.1 + p.2
  
  # storage
  data.Y1 <- array(0,c(n,1,t))
  data.Y2 <- array(0,c(n,1,t))
  data.Y3 <- array(0,c(n,1,t))
  data.Y4 <- array(0,c(n,1,t))
  data.X <- array(0,c(n,p,t))
  
  
  
  
  for (i in 1:t){
    
    # number of genes per transcription factor:
    k   <- p.2/p.1
    # main loop to construct X
    X      <- matrix(0,n,p) 
    sig    <- 0.51
    #l <- 1
    for (jj in 1:n) {
      
      
      X.temp      <- matrix(0,p.1,11)
      TF          <- rnorm(p.1,mean = 0, sd = 1)
      for (ii in 1:p.1) {
        x.temp      <- NULL
        x.temp      <- rnorm(k,mean = 0.7*TF[ii], sd = sqrt(sig))
        X.temp[ii,] <- c(TF[ii], x.temp)
      }
      X[jj,]      <- as.vector(t(X.temp))
    }
    data.X[,,i] <- X
    
    #--response variable---#
    # initializing:
    y.1 <- NULL
    y.2 <- NULL
    y.3 <- NULL
    y.4 <- NULL
    
    # computing variance of each scenario:
    epsilon <- rnorm(n, mean = 0, sd = 1)
    sig.1   <- sqrt(sum((beta.1)^2)/4)
    sig.2   <- sqrt(sum((beta.2)^2)/4)
    sig.3   <- sqrt(sum((beta.3)^2)/4)
    sig.4   <- sqrt(sum((beta.4)^2)/4)
    
    y.1 <- X%*%beta.1 + sig.1*epsilon
    y.2 <- X%*%beta.2 + sig.2*epsilon
    y.3 <- X%*%beta.3 + sig.3*epsilon
    y.4 <- X%*%beta.4 + sig.4*epsilon
    
    # storing:
    data.Y1[,,i] <- y.1
    data.Y2[,,i] <- y.2
    data.Y3[,,i] <- y.3
    data.Y4[,,i] <- y.4
    
  }
  return(list(Y1 = data.Y1, Y2 = data.Y2, Y3 = data.Y3, Y4 = data.Y4, X = data.X))
}









lasso.net.fixed <- function(x ,y ,beta.0 = array(0,length(y)) ,lambda1=c(0,1) ,lambda2=c(0,1) ,M1 ,n.iter = 1e5 ,iscpp=TRUE ,tol=1e-6) {
  # initializing beta
  beta <- beta.0
  
  n1 <- length(lambda1)
  n2 <- length(lambda2)
  # convert to relevant data structure
  beta   <- as.matrix(beta)
  x      <- as.matrix(x)
  M1      <- as.matrix(M1)
  
  # storage
  beta.store  <- array(0,c(length(beta), n2, n1))   
  mse         <- array(0,c(n2,n1))
  n.store     <- array(0,c(n2,n1))
  conv.store2 <- array(0,c(n2,n1))
  # storage for warm starts
  beta.l1w <- numeric(length(beta)) # warm start for lambda1 
  beta.l2w <- numeric(length(beta)) # warm start for lambda2
  g        <- 1
  
  for (i in 1:n2) {
    # loop through lambda2
    cat("Looping through lambda2 - ", i, "\n") 
    for (j in 1:n1) {
      # loop through lambda1
      # initialize convergence:
      betaconv <- FALSE
      cat("Looping through lambda1 - ", j, "\n") 
      
      while(betaconv!=TRUE){
        est <- beta.update.net(x,y,beta,lambda1[j],lambda2[i],M1,n.iter,iscpp)
        if(est$convergence == FALSE) {
          k <- 0
          beta <- est$beta
          n.iter <- n.iter*10
          cat("Coordinate descent alogrithm starts again. GRID VALUES *** lambda1 - ", j, "lambda2 - ", i, " n.iter is set to - " , n.iter ,"\n")
          cat("Current beta estimate - " , est$beta , "\n")
          cat("Current beta warm start - " , beta , "\n") 
        }
        else  {
          
          
          
          # store coordinate descent convergence output
          if(est$convergence == TRUE) {
            betaconv <- TRUE
          } 
          beta <- est$beta
          # store beta
          beta.store[,i,j]  <- beta
          # compute MSE 
          mse[i,j]  <- mean((y - x%*%beta)^2)
          # store number of steps until convergence
          n.store[i,j]     <- est$steps
          
          if(betaconv == FALSE) { # store last boolean value of convergence for betas
            conv.store2[i,j] <- FALSE # at least one of the iterations in M did not have convergence for betas
          }
          else {
            conv.store2[i,j] <- betaconv 
          }
        }
      } # End of coordinate descent converenge check
    } # end of loop (n1)
    
  }  # end of loop (n2)
  
  return(list(beta = beta.store, mse = mse, update.steps = n.store, convergence.in.grid = conv.store2))
  
}


################################################################
#################### REPLICATION FUNCTIONS #####################
################################################################


#--data simulations---#
simul.data      <- function(p.1, p.2, n, beta.1, beta.2, beta.3, beta.4, t) {
  ###
  #  This function simulates the data according to Weber et. al (2014) pape
  # 
  ###
  
  # number of covariates: 
  p <- p.1 + p.2
  
  # storage
  data.Y1 <- array(0,c(n,1,t))
  data.Y2 <- array(0,c(n,1,t))
  data.Y3 <- array(0,c(n,1,t))
  data.Y4 <- array(0,c(n,1,t))
  data.X <- array(0,c(n,p,t))
  
  
  
  
  for (i in 1:t){
    
    # number of genes per transcription factor:
    k   <- p.2/p.1
    # main loop to construct X
    X      <- matrix(0,n,p) 
    sig    <- 0.51
    #l <- 1
    for (jj in 1:n) {
      
      
      X.temp      <- matrix(0,p.1,11)
      TF          <- rnorm(p.1,mean = 0, sd = 1)
      for (ii in 1:p.1) {
        x.temp      <- NULL
        x.temp      <- rnorm(k,mean = 0.7*TF[ii], sd = sqrt(sig))
        X.temp[ii,] <- c(TF[ii], x.temp)
      }
      X[jj,]      <- as.vector(t(X.temp))
    }
    data.X[,,i] <- X
    
    #--response variable---#
    # initializing:
    y.1 <- NULL
    y.2 <- NULL
    y.3 <- NULL
    y.4 <- NULL
    
    # computing variance of each scenario:
    epsilon <- rnorm(n, mean = 0, sd = 1)
    sig.1   <- sqrt(sum((beta.1)^2)/4)
    sig.2   <- sqrt(sum((beta.2)^2)/4)
    sig.3   <- sqrt(sum((beta.3)^2)/4)
    sig.4   <- sqrt(sum((beta.4)^2)/4)
    
    y.1 <- X%*%beta.1 + sig.1*epsilon
    y.2 <- X%*%beta.2 + sig.2*epsilon
    y.3 <- X%*%beta.3 + sig.3*epsilon
    y.4 <- X%*%beta.4 + sig.4*epsilon
    
    # storing:
    data.Y1[,,i] <- y.1
    data.Y2[,,i] <- y.2
    data.Y3[,,i] <- y.3
    data.Y4[,,i] <- y.4
    
  }
  return(list(Y1 = data.Y1, Y2 = data.Y2, Y3 = data.Y3, Y4 = data.Y4, X = data.X))
}



simul.data.sign      <- function(p.1, p.2, n, beta.1, beta.2, beta.3, beta.4, t) {
  ###
  #  This function simulates the data according to Weber et. al (2014) pape
  # 
  ###
  
  # number of covariates: 
  p <- p.1 + p.2
  
  # storage
  data.Y1 <- array(0,c(n,1,t))
  data.Y2 <- array(0,c(n,1,t))
  data.Y3 <- array(0,c(n,1,t))
  data.Y4 <- array(0,c(n,1,t))
  data.X1 <- array(0,c(n,p,t))
  data.X2 <- array(0,c(n,p,t))
  data.X3 <- array(0,c(n,p,t))
  data.X4 <- array(0,c(n,p,t))
  
  b1mat <- matrix(t(beta.1),k+1,p.1)
  b2mat <- matrix(t(beta.2),k+1,p.1)
  b3mat <- matrix(t(beta.3),k+1,p.1)
  b4mat <- matrix(t(beta.4),k+1,p.1)
  
  for (i in 1:t){
    
    # number of genes per transcription factor:
    k   <- p.2/p.1
    # main loop to construct X
    X1      <- matrix(0,n,p)
    X2      <- matrix(0,n,p)
    X3      <- matrix(0,n,p)
    X4      <- matrix(0,n,p)
    sig    <- 0.51
    #l <- 1
    for (jj in 1:n) {
      
      
      X1.temp      <- matrix(0,p.1,11)
      X2.temp      <- matrix(0,p.1,11)
      X3.temp      <- matrix(0,p.1,11)
      X4.temp      <- matrix(0,p.1,11)
      TF          <- rnorm(p.1,mean = 0, sd = 1)
      for (ii in 1:p.1) {
        #x.temp      <- NULL
        x.temp      <- rnorm(k,mean=rep(sign(b1mat[1,ii])*sign(b1mat[2:11,ii])*0.7*TF[ii],k), sd = sqrt(sig))
        X1.temp[ii,] <- c(TF[ii], x.temp)
        x.temp      <- rnorm(k,mean=rep(sign(b2mat[1,ii])*sign(b2mat[2:11,ii])*0.7*TF[ii],k), sd = sqrt(sig))
        X2.temp[ii,] <- c(TF[ii], x.temp)
        x.temp      <- rnorm(k,mean=rep(sign(b3mat[1,ii])*sign(b3mat[2:11,ii])*0.7*TF[ii],k), sd = sqrt(sig))
        X3.temp[ii,] <- c(TF[ii], x.temp)
        x.temp      <- rnorm(k,mean=rep(sign(b4mat[1,ii])*sign(b4mat[2:11,ii])*0.7*TF[ii],k), sd = sqrt(sig))
        X4.temp[ii,] <- c(TF[ii], x.temp)
      }
      X1[jj,]      <- as.vector(t(X1.temp))
      X2[jj,]      <- as.vector(t(X2.temp))
      X3[jj,]      <- as.vector(t(X3.temp))
      X4[jj,]      <- as.vector(t(X4.temp))
    }
    data.X1[,,i] <- X1
    data.X2[,,i] <- X2
    data.X3[,,i] <- X3
    data.X4[,,i] <- X4
    
    #--response variable---#
    # initializing:
    y.1 <- NULL
    y.2 <- NULL
    y.3 <- NULL
    y.4 <- NULL
    
    # computing variance of each scenario:
    epsilon <- rnorm(n, mean = 0, sd = 1)
    sig.1   <- sqrt(sum((beta.1)^2)/4)
    sig.2   <- sqrt(sum((beta.2)^2)/4)
    sig.3   <- sqrt(sum((beta.3)^2)/4)
    sig.4   <- sqrt(sum((beta.4)^2)/4)
    
    y.1 <- X1%*%beta.1 + sig.1*epsilon
    y.2 <- X2%*%beta.2 + sig.2*epsilon
    y.3 <- X3%*%beta.3 + sig.3*epsilon
    y.4 <- X4%*%beta.4 + sig.4*epsilon
    
    # storing:
    data.Y1[,,i] <- y.1
    data.Y2[,,i] <- y.2
    data.Y3[,,i] <- y.3
    data.Y4[,,i] <- y.4
    
  }
  return(list(Y1 = data.Y1, Y2 = data.Y2, Y3 = data.Y3, Y4 = data.Y4, X1 = data.X1,  X2 = data.X2,  X3 = data.X3 , X4 = data.X4))
}

simul.data.single      <- function(p.1, p.2, n, beta.x, t) {
  
  
  # number of covariates: 
  p <- p.1 + p.2
  
  # storage
  data.Y1 <- array(0,c(n,1,t))
  data.X1 <- array(0,c(n,p,t))
  b1mat <- matrix(t(beta.x),k+1,p.1)
  
  for (i in 1:t){
    
    # number of genes per transcription factor:
    k   <- p.2/p.1
    # main loop to construct X
    X1      <- matrix(0,n,p)
    
    sig    <- 0.51
    #l <- 1
    for (jj in 1:n) {
      
      
      X1.temp      <- matrix(0,p.1,11)
      
      TF          <- rnorm(p.1,mean = 0, sd = 1)
      for (ii in 1:p.1) {
        #x.temp      <- NULL
        x.temp      <- rnorm(k,mean=rep(sign(b1mat[1,ii])*sign(b1mat[2:11,ii])*0.7*TF[ii],k), sd = sqrt(sig))
        X1.temp[ii,] <- c(TF[ii], x.temp)
      }
      X1[jj,]      <- as.vector(t(X1.temp))
    }
    data.X1[,,i] <- X1
    
    
    #--response variable---#
    # initializing:
    y.1 <- NULL
    
    
    # computing variance of each scenario:
    epsilon <- rnorm(n, mean = 0, sd = 1)
    sig.1   <- sqrt(sum((beta.1)^2)/4)
    
    
    y.1 <- X1%*%beta.x + sig.1*epsilon
    
    
    # storing:
    data.Y1[,,i] <- y.1
    
    
  }
  return(list(Y1 = data.Y1, X1 = data.X1))
}





run_simulations <- function(data.sim, data.sim.test, beta.0, M, lambda.1, lambda.2, t, n, nfolds = 10, is.fixed = FALSE, tol = 1e-6, n.iter = 1e10, mc = FALSE, ncores = NULL){
  
  if(mc) if(is.null(ncores)){ncores=1}
  
  if(!mc)OUTPUT <- lapply(1:t, main.loop, 
                          data.sim, data.sim.test, 
                          beta.0, M, lambda.1, lambda.2, 
                          n, nfolds, is.fixed, tol) 
  
  if(mc)OUTPUT <- mclapply(1:t, main.loop, 
                           data.sim, data.sim.test, 
                           beta.0, M, lambda.1, lambda.2, 
                           n, nfolds, is.fixed, tol,
                           mc.cores = ncores) 
  
  return(OUTPUT)
}


main.loop <- function(dt,data.sim, data.sim.test, beta.0, M, lambda.1, lambda.2, n, nfolds = 10, is.fixed = FALSE, tol = 1e-6, n.iter = 1e10){
  
  #---params---#
  n1 <- length(lambda.1)
  n2 <- length(lambda.2)
  
  #---simulate data---#
  
  # storage:
  MSFE.t.1   <- NULL
  MSFE.t.2   <- NULL
  MSFE.t.3   <- NULL
  MSFE.t.4   <- NULL
  
  
  lam.comb.1   <- NULL
  lam.comb.2   <- NULL
  lam.comb.3   <- NULL
  lam.comb.4   <- NULL
  
  
  output.t.1    <- NULL
  output.t.2    <- NULL
  output.t.3    <- NULL
  output.t.4    <- NULL
  OUTPUT        <- NULL
  OUTPUT.train  <- NULL
  
  
  output.train.t.1    <- NULL
  output.train.t.2    <- NULL
  output.train.t.3    <- NULL
  output.train.t.4    <- NULL
  
  
  std.cv.1   <- NULL
  std.cv.2   <- NULL
  std.cv.3   <- NULL
  std.cv.4   <- NULL
  #--data train (cross validate) [i] and test [i+1]---#
  
  # i-th data set: training and validating:
  X1      <- scale(data.sim$X1[,,dt] , center = TRUE, scale = TRUE)
  X2      <- scale(data.sim$X2[,,dt] , center = TRUE, scale = TRUE)
  X3      <- scale(data.sim$X3[,,dt] , center = TRUE, scale = TRUE)
  X4      <- scale(data.sim$X4[,,dt] , center = TRUE, scale = TRUE)
  Y1      <- scale(data.sim$Y1[,,dt], center = TRUE, scale = FALSE)
  Y2      <- scale(data.sim$Y2[,,dt], center = TRUE, scale = FALSE) 
  Y3      <- scale(data.sim$Y3[,,dt], center = TRUE, scale = FALSE)
  Y4      <- scale(data.sim$Y4[,,dt], center = TRUE, scale = FALSE) 
  
  
  
  # i-th data set: testing and computing statistics:
  X1.test    <- scale(data.sim.test$X1[,,dt] , center = TRUE, scale = TRUE)
  X2.test    <- scale(data.sim.test$X2[,,dt] , center = TRUE, scale = TRUE)
  X3.test    <- scale(data.sim.test$X3[,,dt] , center = TRUE, scale = TRUE)
  X4.test    <- scale(data.sim.test$X4[,,dt] , center = TRUE, scale = TRUE)
  Y1.test    <- scale(data.sim.test$Y1[,,dt], center = TRUE, scale = FALSE)
  Y2.test    <- scale(data.sim.test$Y2[,,dt], center = TRUE, scale = FALSE)
  Y3.test    <- scale(data.sim.test$Y3[,,dt], center = TRUE, scale = FALSE)
  Y4.test    <- scale(data.sim.test$Y4[,,dt], center = TRUE, scale = FALSE)
  
  
  
  # storage 
  msfeCV.1 <- array(0,c(n2,n1,nfolds))
  msfeCV.2 <- array(0,c(n2,n1,nfolds))
  msfeCV.3 <- array(0,c(n2,n1,nfolds))
  msfeCV.4 <- array(0,c(n2,n1,nfolds))
  
  if (nfolds < 2) 
    stop("nfolds must be bigger than 2; at least 3 would be good; nfolds=10 recommended")
  crossval.ind <- CVfold(n,K = nfolds, is.random = FALSE)
  
  for (d in 1:nfolds){
    cat("Cross validation data set - ", d, "\n")
    cat("Data set - ", dt, "\n")
    train.ind <- crossval.ind[[d]]$train
    val.ind   <- crossval.ind[[d]]$validate
    
    X1.train <- X1[train.ind,]
    X2.train <- X2[train.ind,]
    X3.train <- X3[train.ind,]
    X4.train <- X4[train.ind,]
    Y1.train <- Y1[train.ind]
    Y2.train <- Y2[train.ind]
    Y3.train <- Y3[train.ind]
    Y4.train <- Y4[train.ind]
    
    X1.val   <- X1[val.ind,]
    X2.val   <- X2[val.ind,]
    X3.val   <- X3[val.ind,]
    X4.val   <- X4[val.ind,]
    Y1.val   <- Y1[val.ind]
    Y2.val   <- Y2[val.ind]
    Y3.val   <- Y3[val.ind]
    Y4.val   <- Y4[val.ind]
    
    # CHECK AGAIN 
    if(is.fixed==FALSE){
      cat("(Training data) Computing LassoNet and connection signs\n")
      OUTPUT$OUTPUT.train$output.train.t.1 <- lasso.net.grid(X1.train,Y1.train,beta.0,lambda.1,lambda.2,M, m.iter = 1e2, n.iter = n.iter, iscpp = T, tol = tol, alt.num = 4 )
      beta.1 <- OUTPUT$OUTPUT.train$output.train.t.1$beta
      cat("Beta1 done\n")
      OUTPUT$OUTPUT.train$output.train.t.2 <- lasso.net.grid(X2.train,Y2.train,beta.0,lambda.1,lambda.2,M, m.iter = 1e2, n.iter = n.iter, iscpp = T, tol = tol, alt.num = 4 )
      beta.2 <- OUTPUT$OUTPUT.train$output.train.t.2$beta
      cat("Beta2 done\n")
      OUTPUT$OUTPUT.train$output.train.t.3 <- lasso.net.grid(X3.train,Y3.train,beta.0,lambda.1,lambda.2,M, m.iter = 1e2, n.iter = n.iter, iscpp = T, tol = tol, alt.num = 4 )
      beta.3 <- OUTPUT$OUTPUT.train$output.train.t.3$beta
      cat("Beta3 done\n")
      OUTPUT$OUTPUT.train$output.train.t.4 <- lasso.net.grid(X4.train,Y4.train,beta.0,lambda.1,lambda.2,M, m.iter = 1e2, n.iter = n.iter, iscpp = T, tol = tol, alt.num = 4 )
      beta.4 <- OUTPUT$OUTPUT.train$output.train.t.4$beta
      cat("Beta4 done\n")
    } else {
      cat("(Training data) Computing LassoNet, connections fixed\n")
      OUTPUT$OUTPUT.train$output.train.t.1 <- lasso.net.fixed(X1.train,Y1.train,beta.0,lambda.1,lambda.2,M, n.iter = n.iter, iscpp = T, tol = tol )
      beta.1 <- OUTPUT$OUTPUT.train$output.train.t.1$beta
      cat("Beta1 done\n")
      OUTPUT$OUTPUT.train$output.train.t.2 <- lasso.net.fixed(X2.train,Y2.train,beta.0,lambda.1,lambda.2,M, n.iter = n.iter, iscpp = T, tol = tol )
      beta.2 <- OUTPUT$OUTPUT.train$output.train.t.2$beta
      cat("Beta2 done\n")
      OUTPUT$OUTPUT.train$output.train.t.3 <- lasso.net.fixed(X3.train,Y3.train,beta.0,lambda.1,lambda.2,M, n.iter = n.iter, iscpp = T, tol = tol )
      beta.3 <- OUTPUT$OUTPUT.train$output.train.t.3$beta
      cat("Beta3 done\n")
      OUTPUT$OUTPUT.train$output.train.t.4 <- lasso.net.fixed(X4.train,Y4.train,beta.0,lambda.1,lambda.2,M, n.iter = n.iter, iscpp = T, tol = tol )
      beta.4 <- OUTPUT$OUTPUT.train$output.train.t.4$beta
      cat("Beta4 done\n")
    }
    
    
    
    # error curves:
    for (jj in 1:n2) { # rows - network penalty, columns - lasso penalty
      for (ii in 1:n1){
        
        msfeCV.1[jj,ii,d] <- mean((Y1.val - X1.val%*%beta.1[,jj,ii])^2, na.rm = TRUE)
        msfeCV.2[jj,ii,d] <- mean((Y2.val - X2.val%*%beta.2[,jj,ii])^2, na.rm = TRUE)
        msfeCV.3[jj,ii,d] <- mean((Y3.val - X3.val%*%beta.3[,jj,ii])^2, na.rm = TRUE)
        msfeCV.4[jj,ii,d] <- mean((Y4.val - X4.val%*%beta.4[,jj,ii])^2, na.rm = TRUE)
      }
    }
  }
  # average of CV error curves:
  OUTPUT$MSFE.t.1 <- apply(msfeCV.1, c(1,2), "mean")
  OUTPUT$MSFE.t.2 <- apply(msfeCV.2, c(1,2), "mean")
  OUTPUT$MSFE.t.3 <- apply(msfeCV.3, c(1,2), "mean")
  OUTPUT$MSFE.t.4 <- apply(msfeCV.4, c(1,2), "mean")
  
  # st of CV error curve estimate:
  OUTPUT$std.cv.1 <- apply(msfeCV.1, c(1,2), "sd")/sqrt(nfolds)
  OUTPUT$std.cv.2 <- apply(msfeCV.2, c(1,2), "sd")/sqrt(nfolds)
  OUTPUT$std.cv.3 <- apply(msfeCV.3, c(1,2), "sd")/sqrt(nfolds)
  OUTPUT$std.cv.4 <- apply(msfeCV.4, c(1,2), "sd")/sqrt(nfolds)
  
  # minimum error. lam.comb.1[[i]]: lam.comb.1[2] - lambda1 index, lam.comb.1[1] - lambda2 index
  lam.comb.1 <- which(OUTPUT$MSFE.t.1 == min(OUTPUT$MSFE.t.1), arr.ind = T)
  lam.comb.2 <- which(OUTPUT$MSFE.t.2 == min(OUTPUT$MSFE.t.2), arr.ind = T)
  lam.comb.3 <- which(OUTPUT$MSFE.t.3 == min(OUTPUT$MSFE.t.3), arr.ind = T)
  lam.comb.4 <- which(OUTPUT$MSFE.t.4 == min(OUTPUT$MSFE.t.4), arr.ind = T)
  
  # optimal lambda combinations:
  OUTPUT$optim.lam.1 <- c(lambda.1[lam.comb.1[2]], lambda.2[lam.comb.1[1]])
  OUTPUT$optim.lam.2 <- c(lambda.1[lam.comb.2[2]], lambda.2[lam.comb.2[1]])
  OUTPUT$optim.lam.3 <- c(lambda.1[lam.comb.3[2]], lambda.2[lam.comb.3[1]])
  OUTPUT$optim.lam.4 <- c(lambda.1[lam.comb.4[2]], lambda.2[lam.comb.4[1]])
  
  #--Fitting test data set---#
  # beta.1[,n2,n1] is estimated beta of n2 lambda2 value and n1 lambda1
  cat("(Testing data) Computing LassoNet and connection signs\n")
  OUTPUT$output.t.1 <- mean((Y1.test - X1.test%*%beta.1[,lam.comb.1[1],lam.comb.1[2]])^2)
  cat("MSE using optimal lamba(1,2) values for beta.1 and test data is estimated\n")
  OUTPUT$output.t.2 <- mean((Y2.test - X2.test%*%beta.2[,lam.comb.2[1],lam.comb.2[2]])^2)
  cat("MSE using optimal lamba(1,2) values for beta.2 and test data is estimated\n")
  OUTPUT$output.t.3 <- mean((Y3.test - X3.test%*%beta.3[,lam.comb.3[1],lam.comb.3[2]])^2)
  cat("MSE using optimal lamba(1,2) values for beta.3 and test data is estimated\n")
  OUTPUT$output.t.4 <- mean((Y4.test - X4.test%*%beta.4[,lam.comb.4[1],lam.comb.4[2]])^2)
  cat("MSE using optimal lamba(1,2) values for beta.4 and test data is estimated\n")
  
  return(OUTPUT = OUTPUT)
}



gettable <- function(data.sim,data.sim.test,t,beta.1,beta.2,beta.3,beta.4,out.net.norm, out.net.comb, out.net.fix, out.lasso) {
  
  intercept  <- NULL
  intercept.o <- NULL
  true       <- NULL
  true.o     <- NULL
  net.norm   <- NULL
  net.norm.o <- NULL
  net.comb   <- NULL
  net.comb.o <- NULL
  net.fix    <- NULL
  net.fix.o  <- NULL
  lasso      <- NULL
  lasso.o    <- NULL
  
  
  for (i in 1:t){
    # true model
    true$MSE.1[i] <- mean((data.sim.test$Y1[,,i]-data.sim.test$X1[,,i]%*%beta.1)^2)
    true$MSE.2[i] <- mean((data.sim.test$Y2[,,i]-data.sim.test$X2[,,i]%*%beta.2)^2)
    true$MSE.3[i] <- mean((data.sim.test$Y3[,,i]-data.sim.test$X3[,,i]%*%beta.3)^2)
    true$MSE.4[i] <- mean((data.sim.test$Y4[,,i]-data.sim.test$X4[,,i]%*%beta.4)^2)
    
    # intercept
    intercept$MSE.1[i] <- mean((data.sim.test$Y1[,,i]-mean(data.sim.test$Y1[,,i]))^2)
    intercept$MSE.2[i] <- mean((data.sim.test$Y2[,,i]-mean(data.sim.test$Y2[,,i]))^2)
    intercept$MSE.3[i] <- mean((data.sim.test$Y3[,,i]-mean(data.sim.test$Y3[,,i]))^2)
    intercept$MSE.4[i] <- mean((data.sim.test$Y4[,,i]-mean(data.sim.test$Y4[,,i]))^2)
    
    # lasso network. normalized laplacian
    net.norm$MSE.1[i] <- out.net.norm[[i]]$output.t.1
    net.norm$MSE.2[i] <- out.net.norm[[i]]$output.t.2
    net.norm$MSE.3[i] <- out.net.norm[[i]]$output.t.3
    net.norm$MSE.4[i] <- out.net.norm[[i]]$output.t.4
    
    # lasso network. combinatorial laplacian
    net.comb$MSE.1[i] <- out.net.comb[[i]]$output.t.1
    net.comb$MSE.2[i] <- out.net.comb[[i]]$output.t.2
    net.comb$MSE.3[i] <- out.net.comb[[i]]$output.t.3
    net.comb$MSE.4[i] <- out.net.comb[[i]]$output.t.4
    
    # lasso network. fixed network
    net.fix$MSE.1[i] <- out.net.fix[[i]]$output.t.1
    net.fix$MSE.2[i] <- out.net.fix[[i]]$output.t.2
    net.fix$MSE.3[i] <- out.net.fix[[i]]$output.t.3
    net.fix$MSE.4[i] <- out.net.fix[[i]]$output.t.4
    
    # lasso
    lasso$MSE.1[i] <- out.lasso[[i]]$output.t.1
    lasso$MSE.2[i] <- out.lasso[[i]]$output.t.2
    lasso$MSE.3[i] <- out.lasso[[i]]$output.t.3
    lasso$MSE.4[i] <- out.lasso[[i]]$output.t.4
  }
  # true 
  true.o$.m1 <-  mean(true$MSE.1) 
  true.o$.m2 <-  mean(true$MSE.2) 
  true.o$.m3 <-  mean(true$MSE.3) 
  true.o$.m4 <-  mean(true$MSE.4)
  true.o$.sd1 <- sd(true$MSE.1)/sqrt(t)  
  true.o$.sd2 <- sd(true$MSE.2)/sqrt(t)  
  true.o$.sd3 <- sd(true$MSE.3)/sqrt(t)  
  true.o$.sd4 <- sd(true$MSE.4)/sqrt(t) 
  
  # intercept
  intercept.o$.m1 <-  mean(intercept$MSE.1) 
  intercept.o$.m2 <-  mean(intercept$MSE.2) 
  intercept.o$.m3 <-  mean(intercept$MSE.3) 
  intercept.o$.m4 <-  mean(intercept$MSE.4)
  intercept.o$.sd1 <- sd(intercept$MSE.1)/sqrt(t)  
  intercept.o$.sd2 <- sd(intercept$MSE.2)/sqrt(t)  
  intercept.o$.sd3 <- sd(intercept$MSE.3)/sqrt(t)  
  intercept.o$.sd4 <- sd(intercept$MSE.4)/sqrt(t) 
  
  # lasso network. normalized laplacian
  net.norm.o$.m1  <- mean(net.norm$MSE.1) 
  net.norm.o$.m2  <- mean(net.norm$MSE.2) 
  net.norm.o$.m3  <- mean(net.norm$MSE.3) 
  net.norm.o$.m4  <- mean(net.norm$MSE.4)
  net.norm.o$.sd1 <- sd(net.norm$MSE.1)/sqrt(t) 
  net.norm.o$.sd2 <- sd(net.norm$MSE.2)/sqrt(t) 
  net.norm.o$.sd3 <- sd(net.norm$MSE.3)/sqrt(t) 
  net.norm.o$.sd4 <- sd(net.norm$MSE.4)/sqrt(t)
  
  # lasso network. combinatorial laplacian
  net.comb.o$.m1  <- mean(net.comb$MSE.1) 
  net.comb.o$.m2  <- mean(net.comb$MSE.2) 
  net.comb.o$.m3  <- mean(net.comb$MSE.3) 
  net.comb.o$.m4  <- mean(net.comb$MSE.4)
  net.comb.o$.sd1 <- sd(net.comb$MSE.1)/sqrt(t) 
  net.comb.o$.sd2 <- sd(net.comb$MSE.2)/sqrt(t) 
  net.comb.o$.sd3 <- sd(net.comb$MSE.3)/sqrt(t) 
  net.comb.o$.sd4 <- sd(net.comb$MSE.4)/sqrt(t)
  
  
  # lasso network constrained, fixed. (normalized laplacian)
  net.fix.o$.m1  <- mean(net.fix$MSE.1) 
  net.fix.o$.m2  <- mean(net.fix$MSE.2) 
  net.fix.o$.m3  <- mean(net.fix$MSE.3) 
  net.fix.o$.m4  <- mean(net.fix$MSE.4)
  net.fix.o$.sd1 <- sd(net.fix$MSE.1)/sqrt(t) 
  net.fix.o$.sd2 <- sd(net.fix$MSE.2)/sqrt(t) 
  net.fix.o$.sd3 <- sd(net.fix$MSE.3)/sqrt(t) 
  net.fix.o$.sd4 <- sd(net.fix$MSE.4)/sqrt(t)
  
  
  
  # lasso
  lasso.o$.m1  <- mean(lasso$MSE.1) 
  lasso.o$.m2  <- mean(lasso$MSE.2) 
  lasso.o$.m3  <- mean(lasso$MSE.3) 
  lasso.o$.m4  <- mean(lasso$MSE.4)
  lasso.o$.sd1 <- sd(lasso$MSE.1)/sqrt(t) 
  lasso.o$.sd2 <- sd(lasso$MSE.2)/sqrt(t) 
  lasso.o$.sd3 <- sd(lasso$MSE.3)/sqrt(t) 
  lasso.o$.sd4 <- sd(lasso$MSE.4)/sqrt(t)
  
  
  
  return(list(true=true.o,intercept=intercept.o , net.norm=net.norm.o, net.comb=net.comb.o, net.fix=net.fix.o, lasso=lasso.o))
  
}





run_simulations.single <- function(data.sim, data.sim.test, beta.0, M, lambda.1, lambda.2, t, n, nfolds = 10, is.fixed = FALSE, tol = 1e-6, n.iter = 1e10, mc = FALSE, ncores = NULL){
  
  if(mc) if(is.null(ncores)){ncores=1}
  
  if(!mc)OUTPUT <-lapply(1:t, main.loop.single, 
                         data.sim, data.sim.test, 
                         beta.0, M, lambda.1, lambda.2, 
                         n, nfolds, is.fixed, tol) 
  
  if(mc)OUTPUT <- mclapply(1:t, main.loop.single, 
                           data.sim, data.sim.test, 
                           beta.0, M, lambda.1, lambda.2, 
                           n, nfolds, is.fixed, tol,
                           mc.cores = ncores) 
  
  return(OUTPUT)
  
  
}




main.loop.single <- function(dt,data.sim, data.sim.test, beta.0, M, lambda.1, lambda.2, n, nfolds = 10, is.fixed = FALSE, tol = 1e-6, n.iter = 1e10){
  #---params---#
  n1 <- length(lambda.1)
  n2 <- length(lambda.2)
  
  #---simulate data---#
  
  # storage:
  MSFE.t.1   <- NULL
  lam.comb.1   <- NULL
  output.t.1    <- NULL
  OUTPUT        <- NULL
  output.train.t.1    <- NULL
  std.cv.1   <- NULL
  
  #--data train (cross validate) [i] and test [i+1]---#
  
  # i-th data set: training and validating:
  X1       <- scale(data.sim$X1[,,dt] , center = TRUE, scale = TRUE)
  Y1      <- scale(data.sim$Y1[,,dt], center = TRUE, scale = FALSE)
  
  # i-th data set: testing and computing statistics:
  X1.test     <- scale(data.sim.test$X1[,,dt] , center = TRUE, scale = TRUE)
  Y1.test    <- scale(data.sim.test$Y1[,,dt], center = TRUE, scale = FALSE)
  
  # storage 
  msfeCV.1 <- array(0,c(n2,n1,nfolds))
  
  
  if (nfolds < 2) 
    stop("nfolds must be bigger than 2; at least 3 would be good; nfolds=10 recommended")
  crossval.ind <- CVfold(n,K = nfolds, is.random = FALSE)
  
  for (d in 1:nfolds){
    cat("Cross validation data set - ", d, "\n")
    cat("Data set - ", dt, "\n")
    train.ind <- crossval.ind[[d]]$train
    val.ind   <- crossval.ind[[d]]$validate
    
    X1.train <- X1[train.ind,]
    Y1.train <- Y1[train.ind]
    
    
    X1.val   <- X1[val.ind,]
    Y1.val   <- Y1[val.ind]
    
    
    # CHECK AGAIN 
    if(is.fixed==FALSE){
      cat("(Training data) Computing LassoNet and connection signs\n")
      OUTPUT$output.train.t.1 <- lasso.net.grid(X1.train,Y1.train,beta.0,lambda.1,lambda.2,M, m.iter = 1e2, n.iter = n.iter, iscpp = T, tol = tol, alt.num = 4 )
      beta.x <- OUTPUT$output.train.t.1$beta
      
    } else {
      cat("(Training data) Computing LassoNet, connections fixed\n")
      OUTPUT$output.train.t.1 <- lasso.net.fixed(X1.train,Y1.train,beta.0,lambda.1,lambda.2,M, n.iter = n.iter, iscpp = T, tol = tol )
      beta.x <- OUTPUT$output.train.t.1$beta
      
    }
    
    
    # error curves:
    for (jj in 1:n2) { # rows - network penalty, columns - lasso penalty
      for (ii in 1:n1){
        msfeCV.1[jj,ii,d] <- mean((Y1.val - X1.val%*%beta.x[,jj,ii])^2, na.rm = TRUE)
      }
    }
  }
  # average of CV error curves:
  OUTPUT$MSFE.t.1 <- apply(msfeCV.1, c(1,2), "mean")
  
  # st of CV error curve estimate:
  OUTPUT$std.cv.1 <- apply(msfeCV.1, c(1,2), "sd")/sqrt(nfolds)
  
  
  # minimum error. lam.comb.1[[i]]: lam.comb.1[2] - lambda1 index, lam.comb.1[1] - lambda2 index
  lam.comb.1 <- which(OUTPUT$MSFE.t.1 == min(OUTPUT$MSFE.t.1), arr.ind = T)
  
  
  # optimal lambda combinations:
  OUTPUT$optim.lam.1 <- c(lambda.1[lam.comb.1[2]], lambda.2[lam.comb.1[1]])
  
  
  #--Computing MSE on test data set---#
  
  cat("(Testing data) Computing LassoNet and connection signs\n")
  OUTPUT$output.t.1 <- mean((Y1.test - X1.test%*%beta.x[,lam.comb.1[1],lam.comb.1[2]])^2)
  
  
  return(OUTPUT = OUTPUT)
  
}



gettable.single <- function(data.sim,data.sim.test,t,beta.x,out.net.norm, out.net.comb, out.net.fix, out.lasso) {
  
  intercept  <- NULL
  intercept.o <- NULL
  true       <- NULL
  true.o     <- NULL
  net.norm   <- NULL
  net.norm.o   <- NULL
  net.comb   <- NULL
  net.comb.o   <- NULL
  net.fix    <- NULL
  net.fix.o    <- NULL
  lasso      <- NULL
  lasso.o      <- NULL
  
  
  for (i in 1:t){
    # true model
    true$MSE.1[i] <- mean((data.sim.test$Y1[,,i]-data.sim.test$X[,,i]%*%beta.x)^2)
    # intercept
    intercept$MSE.1[i] <- mean((data.sim.test$Y1[,,i]-mean(data.sim.test$Y1[,,i]))^2)
    # lasso network. normalized laplacian
    net.norm$MSE.1[i] <- out.net.norm[[i]]$output.t.1
    # lasso network. normalized laplacian
    net.comb$MSE.1[i] <- out.net.comb[[i]]$output.t.1
    # lasso network. normalized laplacian
    net.fix$MSE.1[i] <- out.net.fix[[i]]$output.t.1
    # lasso network. normalized laplacian
    lasso$MSE.1[i] <- out.lasso[[i]]$output.t.1
    
  }
  # true 
  true.o$.m1 <-  mean(true$MSE.1) 
  true.o$.sd1 <- sd(true$MSE.1)/sqrt(t)  
  
  
  # intercept
  intercept.o$.m1 <-  mean(intercept$MSE.1) 
  intercept.o$.sd1 <- sd(intercept$MSE.1)/sqrt(t)  
  
  
  # lasso network. normalized laplacian
  net.norm.o$.m1 <- mean(net.norm$MSE.1) 
  net.norm.o$.sd1 <- sd(net.norm$MSE.1)/sqrt(t) 
  
  # lasso network. combinatorial laplacian
  net.comb.o$.m1 <- mean(net.comb$MSE.1) 
  net.comb.o$.sd1 <- sd(net.comb$MSE.1)/sqrt(t) 
  
  
  # lasso fixed network. 
  net.fix.o$.m1 <- mean(net.fix$MSE.1) 
  net.fix.o$.sd1 <- sd(net.fix$MSE.1)/sqrt(t) 
  
  
  # lasso
  lasso.o$.m1 <- mean(lasso$MSE.1) 
  lasso.o$.sd1 <- sd(lasso$MSE.1)/sqrt(t) 
  
  
  
  return(list(true=true.o,intercept=intercept.o , net.norm=net.norm.o, net.comb=net.comb.o, net.fix=net.fix.o, lasso=lasso.o))
  
}







